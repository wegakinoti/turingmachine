/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingmachine;

/**
 *
 * @author wega
 */
public class Transition {
   private String fromState;
   private char read;
   private char write;
   private char direction;
   private String toState;
   
   public Transition(String fromState, char read, char write, char direction, String toState){
      this.fromState = fromState;
      this.read = read;
      this.write = write;
      this.direction = direction;
      this.toState = toState;
   }

   /**
    * @return the fromState
    */
   public String getFromState() {
      return fromState;
   }

   /**
    * @param fromState the fromState to set
    */
   public void setFromState(String fromState) {
      this.fromState = fromState;
   }

   /**
    * @return the read
    */
   public char getRead() {
      return read;
   }

   /**
    * @param read the read to set
    */
   public void setRead(char read) {
      this.read = read;
   }

   /**
    * @return the write
    */
   public char getWrite() {
      return write;
   }

   /**
    * @param write the write to set
    */
   public void setWrite(char write) {
      this.write = write;
   }

   /**
    * @return the direction
    */
   public char getDirection() {
      return direction;
   }

   /**
    * @param direction the direction to set
    */
   public void setDirection(char direction) {
      this.direction = direction;
   }

   /**
    * @return the toState
    */
   public String getToState() {
      return toState;
   }

   /**
    * @param toState the toState to set
    */
   public void setToState(String toState) {
      this.toState = toState;
   }
   
   
}
