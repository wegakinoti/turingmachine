/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turingmachine;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author Wega Kinoti
 */
public class TuringMachine {

   static String startState;
   static String rejectState;
   static TuringMachine tm = new TuringMachine();
   static ArrayList<String> acceptStates = new ArrayList<>();
   static ArrayList<String> tmFile = new ArrayList<>();
   static ArrayList<Character> inputAlphabet = new ArrayList<>();
   static ArrayList<Transition> transitions = new ArrayList<>();
   
   public static void fileChooser(){
      System.out.println("Please choose file containing Turing Machine");
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
      int selection = fileChooser.showOpenDialog(null);
      if(selection == JFileChooser.APPROVE_OPTION){
         File selected = fileChooser.getSelectedFile();
         System.out.println("User picked file: " + selected.getAbsolutePath());
         try{
            Scanner scan = new Scanner(selected);
            while (scan.hasNextLine()){
               tmFile.add(scan.nextLine());
            }
            scan.close();
         } 
         catch (FileNotFoundException e){
            System.out.println("Error");
         } 
      }
   }
   
   public static ArrayList<String> acceptStates(){
      startState = tmFile.get(0);
      System.out.println("Start State: " + startState);
      String [] accept = tmFile.get(1).split(" ");
      acceptStates = new ArrayList<>(Arrays.asList(accept));
      System.out.println("Accept States: " + acceptStates);
      rejectState = tmFile.get(2);
      System.out.println("Reject State: " + rejectState);
      return acceptStates;
   }
   
   public static ArrayList<Transition> transitions(){
      Tape tape = new Tape();
      for (int i = 4 ; i < tmFile.size(); i++){
         String [] data = tmFile.get(i).split(""); 
         String fromState = data[0] + data[1];
         String toState = data[11] + data[12];
         char read = data[4].charAt(0);
         char write = data[6].charAt(0);
         char direction = data[8].charAt(0);
         
         Transition transition = new Transition(fromState, read, write, direction, toState);
         transitions.add(transition);
      }
      return transitions;
   }
   
   public void setTransitions(ArrayList<Transition> transitions) {
        tm.transitions = transitions;
    } 
   
   public static ArrayList<Character> tapeAlphabet(){ //checka the 4th row
      
      String [] start = tmFile.get(3).split(" ");
      for(int i = 0; i < start.length; i++){
         char letter = start[i].charAt(0);
         if(!inputAlphabet.contains(letter)){
            inputAlphabet.add(letter);
         }   
      }
      
      System.out.println("Alphabet is: " + inputAlphabet);;
      
      return inputAlphabet;
   }
   
   public static boolean acceptInput(String userInput){
      Tape tape = new Tape();
      tape.initialize(userInput);
      String current = startState;
      while (!acceptStates.contains(current) && !rejectState.equals(current)){
         for (Transition next : transitions) {    
            if ((next.getFromState().contains(current)) && (next.getRead() == tape.cells.get(tape.headPosition)) ) {              
                   tape.write(next.getWrite(), next.getDirection());
                   current = next.getToState();
                   break;
            }
         }
      }
      
      if (acceptStates.contains(current)){
         System.out.println("The input string is accepted");
         return true;
      }else{
         System.out.println("The input string is NOT accepted");
         return false;
      }
   }

   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) {
      fileChooser();
      acceptStates();
      transitions();
      tapeAlphabet();
      
      String userInput = JOptionPane.showInputDialog("Please enter a string");
      acceptInput(userInput); //checks if User Input works
      
      String userContinue = JOptionPane.showInputDialog("Would you like to enter another string? Enter a Y to continue");//loop to check as many strings as you desire
      if (userContinue.equals("Y")){
         do{
            userInput = JOptionPane.showInputDialog("Please enter a string");
            acceptInput(userInput);
            userContinue = JOptionPane.showInputDialog("Would you like to enter another string? Enter a Y to continue");
         } while (userContinue.equals("Y"));
      }
      
      
   }
   
}
